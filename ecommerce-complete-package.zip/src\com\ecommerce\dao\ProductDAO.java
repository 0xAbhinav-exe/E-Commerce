package com.ecommerce.dao;

import com.ecommerce.model.*;
import com.ecommerce.util.DBConnection;
import com.ecommerce.exception.DatabaseException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {

    public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        String sql = "SELECT * FROM products";

        try (Connection conn = DBConnection.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                products.add(mapResultSetToProduct(rs));
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error fetching products.", e);
        }
        return products;
    }

    public Product getProductById(int id) {
        String sql = "SELECT * FROM products WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToProduct(rs);
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error fetching product by ID.", e);
        }
        return null;
    }

    public void addProduct(Product product) {
        String sql;
        if (product.getId() > 0) {
            sql = "INSERT INTO products (id, name, category, price, stock, brand, attributes, image_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        } else {
            sql = "INSERT INTO products (name, category, price, stock, brand, attributes, image_path) VALUES (?, ?, ?, ?, ?, ?, ?)";
        }

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            int paramIndex = 1;
            if (product.getId() > 0) {
                stmt.setInt(paramIndex++, product.getId());
            }

            stmt.setString(paramIndex++, product.getName());
            stmt.setString(paramIndex++, product.getCategory());
            stmt.setDouble(paramIndex++, product.getPrice());
            stmt.setInt(paramIndex++, product.getStock());
            stmt.setString(paramIndex++, product.getBrand());

            if (product instanceof SmartDevice) {
                stmt.setString(paramIndex++, ((SmartDevice) product).getConnectivity());
            } else if (product instanceof Accessory) {
                stmt.setString(paramIndex++, ((Accessory) product).getCompatibility());
            } else {
                stmt.setString(paramIndex++, null);
            }

            stmt.setString(paramIndex++, product.getImagePath());

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error adding product.", e);
        }
    }

    public void updateStock(int productId, int newStock) {
        String sql = "UPDATE products SET stock = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, newStock);
            stmt.setInt(2, productId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error updating stock.", e);
        }
    }

    public void deleteProduct(int productId) {
        String sql = "DELETE FROM products WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, productId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error deleting product.", e);
        }
    }

    private Product mapResultSetToProduct(ResultSet rs) throws SQLException {
        int id = rs.getInt("id");
        String name = rs.getString("name");
        String category = rs.getString("category");
        double price = rs.getDouble("price");
        int stock = rs.getInt("stock");
        String brand = rs.getString("brand");
        String attributes = rs.getString("attributes");
        String imagePath = rs.getString("image_path");

        if ("SmartDevice".equalsIgnoreCase(category)) {
            return new SmartDevice(id, name, price, stock, brand, attributes, imagePath);
        } else if ("Accessory".equalsIgnoreCase(category)) {
            return new Accessory(id, name, price, stock, brand, attributes, imagePath);
        } else {
            return new Electronic(id, name, price, stock, brand, imagePath);
        }
    }

    public void updateProduct(Product product) {
        String sql = "UPDATE products SET name=?, category=?, price=?, stock=?, brand=?, attributes=?, image_path=? WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, product.getName());
            stmt.setString(2, product.getCategory());
            stmt.setDouble(3, product.getPrice());
            stmt.setInt(4, product.getStock());
            stmt.setString(5, product.getBrand());

            if (product instanceof SmartDevice) {
                stmt.setString(6, ((SmartDevice) product).getConnectivity());
            } else if (product instanceof Accessory) {
                stmt.setString(6, ((Accessory) product).getCompatibility());
            } else {
                stmt.setString(6, null);
            }

            stmt.setString(7, product.getImagePath());
            stmt.setInt(8, product.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("Error updating product.", e);
        }
    }
}
