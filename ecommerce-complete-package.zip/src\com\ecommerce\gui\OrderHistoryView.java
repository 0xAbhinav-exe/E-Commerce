package com.ecommerce.gui;

import com.ecommerce.dao.OrderDAO;
import com.ecommerce.model.Order;
import com.ecommerce.model.OrderItem;
import com.ecommerce.model.User;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.util.List;

public class OrderHistoryView {

    private User user;
    private OrderDAO orderDAO;
    private VBox ordersContainer;

    public OrderHistoryView(User user) {
        this.user = user;
        this.orderDAO = new OrderDAO();
    }

    public Parent getView() {
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: #0D1B2A;");

        // Header
        HBox header = createHeader();
        root.setTop(header);

        // Orders List
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color: transparent; -fx-background: transparent;");

        ordersContainer = new VBox(15);
        ordersContainer.setPadding(new Insets(20, 0, 20, 0));

        loadOrders();

        scrollPane.setContent(ordersContainer);
        root.setCenter(scrollPane);

        return root;
    }

    private HBox createHeader() {
        HBox header = new HBox(15);
        header.setPadding(new Insets(0, 0, 20, 0));
        header.setAlignment(Pos.CENTER_LEFT);

        Label titleLabel = new Label("📦 My Orders");
        titleLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 28));
        titleLabel.setStyle("-fx-text-fill: #778DA9;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button backButton = new Button("← Back to Dashboard");
        backButton.getStyleClass().add("nav-button");
        backButton.setOnAction(e -> EcommerceApp.showDashboard(user));

        header.getChildren().addAll(titleLabel, spacer, backButton);
        return header;
    }

    private void loadOrders() {
        ordersContainer.getChildren().clear();

        List<Order> orders = orderDAO.getOrdersByUserId(user.getId());

        if (orders.isEmpty()) {
            ordersContainer.getChildren().add(createEmptyState());
        } else {
            for (Order order : orders) {
                ordersContainer.getChildren().add(createOrderCard(order));
            }
        }
    }

    private VBox createEmptyState() {
        VBox emptyBox = new VBox(20);
        emptyBox.setAlignment(Pos.CENTER);
        emptyBox.setPadding(new Insets(80));
        emptyBox.getStyleClass().add("order-empty-state");

        Label emptyIcon = new Label("📦");
        emptyIcon.setFont(Font.font(72));

        Label emptyLabel = new Label("No Orders Yet");
        emptyLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));
        emptyLabel.setStyle("-fx-text-fill: #E0E1DD;");

        Label emptySubLabel = new Label("Start shopping to see your orders here!");
        emptySubLabel.setStyle("-fx-text-fill: #778DA9; -fx-font-size: 14px;");

        emptyBox.getChildren().addAll(emptyIcon, emptyLabel, emptySubLabel);
        return emptyBox;
    }

    private VBox createOrderCard(Order order) {
        VBox card = new VBox(12);
        card.getStyleClass().add("order-card");

        // Header row with order ID and status
        HBox headerRow = new HBox(15);
        headerRow.setAlignment(Pos.CENTER_LEFT);

        Label orderIdLabel = new Label("Order #" + order.getId());
        orderIdLabel.getStyleClass().add("order-id-label");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label statusBadge = createStatusBadge(order.getStatus());

        headerRow.getChildren().addAll(orderIdLabel, spacer, statusBadge);

        // Date and total row
        HBox infoRow = new HBox(20);
        infoRow.setAlignment(Pos.CENTER_LEFT);

        Label dateLabel = new Label("📅 " + order.getOrderDate());
        dateLabel.getStyleClass().add("order-date-label");

        Label totalLabel = new Label("Total: ₹" + String.format("%.2f", order.getTotalAmount()));
        totalLabel.getStyleClass().add("order-total-label");

        infoRow.getChildren().addAll(dateLabel, totalLabel);

        // Items summary
        Label itemsLabel = new Label(order.getOrderItems().size() + " item(s)");
        itemsLabel.setStyle("-fx-text-fill: #778DA9; -fx-font-size: 13px;");

        // View Details Button
        Button viewDetailsBtn = new Button("View Details");
        viewDetailsBtn.getStyleClass().add("button");
        viewDetailsBtn.setOnAction(e -> showOrderDetails(order));

        card.getChildren().addAll(headerRow, infoRow, itemsLabel, viewDetailsBtn);

        // Make card clickable
        card.setOnMouseClicked(e -> showOrderDetails(order));

        return card;
    }

    private Label createStatusBadge(String status) {
        Label badge = new Label(status.toUpperCase());
        badge.getStyleClass().addAll("status-badge", "status-" + status.toLowerCase());
        return badge;
    }

    private void showOrderDetails(Order order) {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("Order Details - #" + order.getId());

        BorderPane root = new BorderPane();
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: #0D1B2A;");

        // Header
        VBox header = new VBox(10);
        Label titleLabel = new Label("Order #" + order.getId());
        titleLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));
        titleLabel.setStyle("-fx-text-fill: #778DA9;");

        HBox statusRow = new HBox(15);
        statusRow.setAlignment(Pos.CENTER_LEFT);
        Label dateLabel = new Label("Date: " + order.getOrderDate());
        dateLabel.setStyle("-fx-text-fill: #E0E1DD; -fx-font-size: 14px;");
        Label statusBadge = createStatusBadge(order.getStatus());
        statusRow.getChildren().addAll(dateLabel, statusBadge);

        header.getChildren().addAll(titleLabel, statusRow);
        root.setTop(header);

        // Items List
        VBox itemsBox = new VBox(10);
        itemsBox.setPadding(new Insets(20, 0, 20, 0));

        Label itemsHeader = new Label("Order Items:");
        itemsHeader.setFont(Font.font("Segoe UI", FontWeight.BOLD, 16));
        itemsHeader.setStyle("-fx-text-fill: #E0E1DD;");
        itemsBox.getChildren().add(itemsHeader);

        for (OrderItem item : order.getOrderItems()) {
            itemsBox.getChildren().add(createOrderItemCard(item));
        }

        ScrollPane scrollPane = new ScrollPane(itemsBox);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color: transparent; -fx-background: transparent;");
        root.setCenter(scrollPane);

        // Summary
        VBox summary = new VBox(8);
        summary.setPadding(new Insets(15));
        summary.setStyle(
                "-fx-background-color: #1B263B; -fx-background-radius: 8; -fx-border-color: #415A77; -fx-border-radius: 8;");

        double subtotal = order.getTotalAmount() / 1.08; // Remove tax
        double tax = order.getTotalAmount() - subtotal;

        Label subtotalLabel = new Label(String.format("Subtotal: ₹%.2f", subtotal));
        subtotalLabel.setStyle("-fx-text-fill: #E0E1DD; -fx-font-size: 14px;");

        Label taxLabel = new Label(String.format("Tax (8%%): ₹%.2f", tax));
        taxLabel.setStyle("-fx-text-fill: #E0E1DD; -fx-font-size: 14px;");

        Separator separator = new Separator();

        Label totalLabel = new Label(String.format("Total: ₹%.2f", order.getTotalAmount()));
        totalLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
        totalLabel.setStyle("-fx-text-fill: #778DA9;");

        summary.getChildren().addAll(subtotalLabel, taxLabel, separator, totalLabel);
        root.setBottom(summary);

        Scene scene = new Scene(root, 600, 500);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        dialog.setScene(scene);
        dialog.show();
    }

    private HBox createOrderItemCard(OrderItem item) {
        HBox card = new HBox(15);
        card.getStyleClass().add("order-item-card");
        card.setAlignment(Pos.CENTER_LEFT);

        // Product Info
        VBox infoBox = new VBox(5);
        HBox.setHgrow(infoBox, Priority.ALWAYS);

        Label nameLabel = new Label(item.getProductName());
        nameLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 14));
        nameLabel.setStyle("-fx-text-fill: #E0E1DD;");

        Label brandLabel = new Label(item.getProductBrand());
        brandLabel.setStyle("-fx-text-fill: #778DA9; -fx-font-size: 12px;");

        Label quantityLabel = new Label("Quantity: " + item.getQuantity());
        quantityLabel.setStyle("-fx-text-fill: #E0E1DD; -fx-font-size: 12px;");

        infoBox.getChildren().addAll(nameLabel, brandLabel, quantityLabel);

        // Price
        VBox priceBox = new VBox(5);
        priceBox.setAlignment(Pos.CENTER_RIGHT);

        Label priceLabel = new Label(String.format("₹%.2f", item.getPriceAtPurchase()));
        priceLabel.setStyle("-fx-text-fill: #778DA9; -fx-font-size: 13px;");

        Label subtotalLabel = new Label(String.format("₹%.2f", item.getSubtotal()));
        subtotalLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 16));
        subtotalLabel.setStyle("-fx-text-fill: #778DA9;");

        priceBox.getChildren().addAll(priceLabel, subtotalLabel);

        card.getChildren().addAll(infoBox, priceBox);
        return card;
    }
}
