package com.ecommerce.model;

public class Accessory extends Product {
    private String compatibility;

    public Accessory(int id, String name, double price, int stock, String brand, String compatibility,
            String imagePath) {
        super(id, name, "Accessory", price, stock, brand, imagePath);
        this.compatibility = compatibility;
    }

    public String getCompatibility() {
        return compatibility;
    }

    @Override
    public double getDiscount() {
        // 5% discount for accessories
        return 0.05;
    }
}
