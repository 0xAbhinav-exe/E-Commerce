package com.ecommerce.dao;

import com.ecommerce.model.CartItem;
import com.ecommerce.model.User;
import com.ecommerce.util.DBConnection;
import com.ecommerce.exception.DatabaseException;

import java.sql.*;
import java.time.LocalDate;
import java.util.List;

public class OrderDAO {

    public void placeOrder(User user, List<CartItem> items, double totalAmount) {
        String insertOrderSQL = "INSERT INTO orders (user_id, total_amount, order_date) VALUES (?, ?, ?)";
        String insertOrderItemSQL = "INSERT INTO order_items (order_id, product_id, quantity, price_at_purchase) VALUES (?, ?, ?, ?)";
        String updateStockSQL = "UPDATE products SET stock = stock - ? WHERE id = ?";

        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false); // Start Transaction

            // 1. Insert Order
            int orderId = -1;
            try (PreparedStatement orderStmt = conn.prepareStatement(insertOrderSQL, Statement.RETURN_GENERATED_KEYS)) {
                orderStmt.setInt(1, user.getId());
                orderStmt.setDouble(2, totalAmount);
                orderStmt.setString(3, LocalDate.now().toString());
                orderStmt.executeUpdate();

                try (ResultSet generatedKeys = orderStmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        orderId = generatedKeys.getInt(1);
                    } else {
                        throw new SQLException("Creating order failed, no ID obtained.");
                    }
                }
            }

            // 2. Insert Order Items and Update Stock
            try (PreparedStatement itemStmt = conn.prepareStatement(insertOrderItemSQL);
                    PreparedStatement stockStmt = conn.prepareStatement(updateStockSQL)) {

                for (CartItem item : items) {
                    // Insert Item
                    itemStmt.setInt(1, orderId);
                    itemStmt.setInt(2, item.getProduct().getId());
                    itemStmt.setInt(3, item.getQuantity());
                    itemStmt.setDouble(4, item.getProduct().getPrice());
                    itemStmt.addBatch();

                    // Update Stock
                    stockStmt.setInt(1, item.getQuantity());
                    stockStmt.setInt(2, item.getProduct().getId());
                    stockStmt.addBatch();
                }

                itemStmt.executeBatch();
                stockStmt.executeBatch();
            }

            conn.commit(); // Commit Transaction
            System.out.println("Order placed successfully!");

        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback(); // Rollback on error
                    System.err.println("Transaction rolled back.");
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            throw new DatabaseException("Error placing order.", e);
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // Get all orders for a specific user
    public java.util.List<com.ecommerce.model.Order> getOrdersByUserId(int userId) {
        java.util.List<com.ecommerce.model.Order> orders = new java.util.ArrayList<>();
        String sql = "SELECT o.id, o.user_id, u.username, o.total_amount, o.order_date, o.status " +
                "FROM orders o " +
                "JOIN users u ON o.user_id = u.id " +
                "WHERE o.user_id = ? " +
                "ORDER BY o.id DESC";

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    com.ecommerce.model.Order order = new com.ecommerce.model.Order(
                            rs.getInt("id"),
                            rs.getInt("user_id"),
                            rs.getString("username"),
                            rs.getDouble("total_amount"),
                            rs.getString("order_date"),
                            rs.getString("status") != null ? rs.getString("status") : "Pending");
                    orders.add(order);
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error retrieving orders for user.", e);
        }

        // Load order items for each order AFTER ResultSet is closed
        for (com.ecommerce.model.Order order : orders) {
            order.setOrderItems(getOrderItems(order.getId()));
        }

        return orders;
    }

    // Get all orders (for admin)
    public java.util.List<com.ecommerce.model.Order> getAllOrders() {
        java.util.List<com.ecommerce.model.Order> orders = new java.util.ArrayList<>();
        String sql = "SELECT o.id, o.user_id, u.username, o.total_amount, o.order_date, o.status " +
                "FROM orders o " +
                "JOIN users u ON o.user_id = u.id " +
                "ORDER BY o.id DESC";

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                com.ecommerce.model.Order order = new com.ecommerce.model.Order(
                        rs.getInt("id"),
                        rs.getInt("user_id"),
                        rs.getString("username"),
                        rs.getDouble("total_amount"),
                        rs.getString("order_date"),
                        rs.getString("status") != null ? rs.getString("status") : "Pending");
                orders.add(order);
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error retrieving all orders.", e);
        }

        // Load order items for each order AFTER ResultSet is closed
        for (com.ecommerce.model.Order order : orders) {
            order.setOrderItems(getOrderItems(order.getId()));
        }

        return orders;
    }

    // Get a single order by ID
    public com.ecommerce.model.Order getOrderById(int orderId) {
        String sql = "SELECT o.id, o.user_id, u.username, o.total_amount, o.order_date, o.status " +
                "FROM orders o " +
                "JOIN users u ON o.user_id = u.id " +
                "WHERE o.id = ?";

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, orderId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    com.ecommerce.model.Order order = new com.ecommerce.model.Order(
                            rs.getInt("id"),
                            rs.getInt("user_id"),
                            rs.getString("username"),
                            rs.getDouble("total_amount"),
                            rs.getString("order_date"),
                            rs.getString("status") != null ? rs.getString("status") : "Pending");
                    // Load order items
                    order.setOrderItems(getOrderItems(order.getId()));
                    return order;
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error retrieving order.", e);
        }
        return null;
    }

    // Get order items for a specific order
    public java.util.List<com.ecommerce.model.OrderItem> getOrderItems(int orderId) {
        java.util.List<com.ecommerce.model.OrderItem> items = new java.util.ArrayList<>();
        String sql = "SELECT oi.id, oi.order_id, oi.product_id, p.name, p.brand, p.attributes, " +
                "oi.quantity, oi.price_at_purchase " +
                "FROM order_items oi " +
                "JOIN products p ON oi.product_id = p.id " +
                "WHERE oi.order_id = ?";

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, orderId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    // Use attributes field as image path (or default)
                    String imagePath = "assets/default.png";
                    com.ecommerce.model.OrderItem item = new com.ecommerce.model.OrderItem(
                            rs.getInt("id"),
                            rs.getInt("order_id"),
                            rs.getInt("product_id"),
                            rs.getString("name"),
                            rs.getString("brand"),
                            imagePath,
                            rs.getInt("quantity"),
                            rs.getDouble("price_at_purchase"));
                    items.add(item);
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error retrieving order items.", e);
        }
        return items;
    }

    // Update order status
    public void updateOrderStatus(int orderId, String status) {
        String sql = "UPDATE orders SET status = ? WHERE id = ?";

        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, status);
            stmt.setInt(2, orderId);
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Order #" + orderId + " status updated to: " + status);
            } else {
                throw new DatabaseException("Order not found: " + orderId, null);
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error updating order status.", e);
        }
    }
}
