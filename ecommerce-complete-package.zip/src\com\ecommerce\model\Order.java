package com.ecommerce.model;

import java.util.ArrayList;
import java.util.List;

public class Order {
    private int id;
    private int userId;
    private String username;
    private double totalAmount;
    private String orderDate;
    private String status;
    private List<OrderItem> orderItems;

    // Constructor with all fields
    public Order(int id, int userId, String username, double totalAmount, String orderDate, String status) {
        this.id = id;
        this.userId = userId;
        this.username = username;
        this.totalAmount = totalAmount;
        this.orderDate = orderDate;
        this.status = status;
        this.orderItems = new ArrayList<>();
    }

    // Constructor without items (for initial creation)
    public Order(int id, int userId, double totalAmount, String orderDate, String status) {
        this(id, userId, "", totalAmount, orderDate, status);
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<OrderItem> getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(List<OrderItem> orderItems) {
        this.orderItems = orderItems;
    }

    public void addOrderItem(OrderItem item) {
        this.orderItems.add(item);
    }

    @Override
    public String toString() {
        return "Order #" + id + " - " + username + " - ₹" + String.format("%.2f", totalAmount) + " - " + status;
    }
}
