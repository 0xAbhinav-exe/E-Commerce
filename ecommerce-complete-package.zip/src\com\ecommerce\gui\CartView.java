package com.ecommerce.gui;

import com.ecommerce.model.CartItem;
import com.ecommerce.model.User;
import com.ecommerce.service.OrderService;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.io.File;
import java.util.List;

public class CartView {

    private List<CartItem> cartItems;
    private User user;
    private OrderService orderService;
    private VBox itemsContainer;
    private Label subtotalLabel;
    private Label taxLabel;
    private Label grandTotalLabel;

    public CartView(List<CartItem> cartItems, User user) {
        this.cartItems = cartItems;
        this.user = user;
        this.orderService = new OrderService();
    }

    public Parent getView() {
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: #0D1B2A;");

        // Header
        HBox header = createHeader();
        root.setTop(header);

        // Center - Cart Items
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color: transparent; -fx-background: transparent;");

        itemsContainer = new VBox(15);
        itemsContainer.setPadding(new Insets(20, 0, 20, 0));

        if (cartItems.isEmpty()) {
            itemsContainer.getChildren().add(createEmptyCartView());
        } else {
            for (CartItem item : cartItems) {
                itemsContainer.getChildren().add(createCartItemCard(item));
            }
        }

        scrollPane.setContent(itemsContainer);
        root.setCenter(scrollPane);

        // Bottom - Summary
        VBox summaryBox = createSummaryBox();
        root.setBottom(summaryBox);

        return root;
    }

    private HBox createHeader() {
        HBox header = new HBox();
        header.setPadding(new Insets(0, 0, 20, 0));
        header.setAlignment(Pos.CENTER_LEFT);

        Label titleLabel = new Label("Shopping Cart");
        titleLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));
        titleLabel.setStyle("-fx-text-fill: #778DA9;");

        Label itemCountLabel = new Label("(" + cartItems.size() + " items)");
        itemCountLabel.setFont(Font.font("Segoe UI", 16));
        itemCountLabel.setStyle("-fx-text-fill: #aaa; -fx-padding: 0 0 0 10;");

        header.getChildren().addAll(titleLabel, itemCountLabel);
        return header;
    }

    private VBox createEmptyCartView() {
        VBox emptyBox = new VBox(20);
        emptyBox.setAlignment(Pos.CENTER);
        emptyBox.setPadding(new Insets(60));

        Label emptyIcon = new Label("🛒");
        emptyIcon.setFont(Font.font(72));

        Label emptyLabel = new Label("Your cart is empty");
        emptyLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 20));
        emptyLabel.setStyle("-fx-text-fill: white;");

        Label emptySubLabel = new Label("Add some products to get started!");
        emptySubLabel.setStyle("-fx-text-fill: #aaa;");

        emptyBox.getChildren().addAll(emptyIcon, emptyLabel, emptySubLabel);
        return emptyBox;
    }

    private HBox createCartItemCard(CartItem item) {
        HBox card = new HBox(15);
        card.setPadding(new Insets(15));
        card.setAlignment(Pos.CENTER_LEFT);
        card.setStyle("-fx-background-color: #1B263B; -fx-background-radius: 8; " +
                "-fx-border-color: #415A77; -fx-border-radius: 8;");

        // Product Image
        ImageView imageView = new ImageView();
        imageView.setFitWidth(80);
        imageView.setFitHeight(80);
        imageView.setPreserveRatio(true);

        try {
            String imagePath = item.getProduct().getImagePath();
            if (imagePath != null && !imagePath.isEmpty()) {
                String path = "/" + imagePath;
                java.net.URL imgUrl = getClass().getResource(path);

                if (imgUrl != null) {
                    imageView.setImage(new Image(imgUrl.toExternalForm()));
                } else {
                    File imgFile = new File("bin/" + imagePath);
                    if (imgFile.exists()) {
                        imageView.setImage(new Image(imgFile.toURI().toString()));
                    }
                }
            }
        } catch (Exception e) {
            // Use default if image fails to load
        }

        // Product Info
        VBox infoBox = new VBox(5);
        HBox.setHgrow(infoBox, Priority.ALWAYS);

        Label nameLabel = new Label(item.getProduct().getName());
        nameLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 16));
        nameLabel.setStyle("-fx-text-fill: white;");

        Label brandLabel = new Label(item.getProduct().getBrand());
        brandLabel.setStyle("-fx-text-fill: #aaa; -fx-font-size: 12px;");

        Label priceLabel = new Label(String.format("₹%.2f", item.getProduct().getPrice()));
        priceLabel.setStyle("-fx-text-fill: #778DA9; -fx-font-size: 14px; -fx-font-weight: bold;");

        infoBox.getChildren().addAll(nameLabel, brandLabel, priceLabel);

        // Quantity Controls
        HBox quantityBox = new HBox(10);
        quantityBox.setAlignment(Pos.CENTER);

        Button decreaseBtn = new Button("-");
        decreaseBtn.setStyle("-fx-background-color: #415A77; -fx-text-fill: white; " +
                "-fx-font-size: 16px; -fx-font-weight: bold; -fx-min-width: 35; -fx-min-height: 35;");
        decreaseBtn.setOnAction(e -> {
            if (item.getQuantity() > 1) {
                item.setQuantity(item.getQuantity() - 1);
                refreshCart();
            }
        });

        Label qtyLabel = new Label(String.valueOf(item.getQuantity()));
        qtyLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 16));
        qtyLabel.setStyle("-fx-text-fill: white; -fx-min-width: 30; -fx-alignment: center;");

        Button increaseBtn = new Button("+");
        increaseBtn.setStyle("-fx-background-color: #778DA9; -fx-text-fill: white; " +
                "-fx-font-size: 16px; -fx-font-weight: bold; -fx-min-width: 35; -fx-min-height: 35;");
        increaseBtn.setOnAction(e -> {
            if (item.getQuantity() < item.getProduct().getStock()) {
                item.setQuantity(item.getQuantity() + 1);
                refreshCart();
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Stock Limit");
                alert.setHeaderText("Cannot add more items");
                alert.setContentText("Only " + item.getProduct().getStock() + " items available in stock.");
                alert.showAndWait();
            }
        });

        quantityBox.getChildren().addAll(decreaseBtn, qtyLabel, increaseBtn);

        // Item Total
        VBox totalBox = new VBox(5);
        totalBox.setAlignment(Pos.CENTER_RIGHT);
        totalBox.setMinWidth(120);

        Label totalTitleLabel = new Label("Total");
        totalTitleLabel.setStyle("-fx-text-fill: #aaa; -fx-font-size: 12px;");

        Label itemTotalLabel = new Label(String.format("₹%.2f", item.getTotalPrice()));
        itemTotalLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
        itemTotalLabel.setStyle("-fx-text-fill: #778DA9;");

        totalBox.getChildren().addAll(totalTitleLabel, itemTotalLabel);

        // Remove Button
        Button removeBtn = new Button("✕");
        removeBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: #FF6B6B; " +
                "-fx-font-size: 20px; -fx-cursor: hand;");
        removeBtn.setOnAction(e -> {
            cartItems.remove(item);
            refreshCart();
        });

        card.getChildren().addAll(imageView, infoBox, quantityBox, totalBox, removeBtn);
        return card;
    }

    private VBox createSummaryBox() {
        VBox summaryBox = new VBox(15);
        summaryBox.setPadding(new Insets(20, 0, 0, 0));
        summaryBox.setStyle("-fx-background-color: #1B263B; -fx-background-radius: 8; -fx-padding: 20;");

        // Summary Title
        Label summaryTitle = new Label("Order Summary");
        summaryTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
        summaryTitle.setStyle("-fx-text-fill: white;");

        Separator separator1 = new Separator();

        // Calculate totals
        double total = orderService.calculateTotal(cartItems);
        double tax = orderService.calculateTax(total);
        double grandTotal = total + tax;

        // Subtotal
        HBox subtotalRow = createSummaryRow("Subtotal:", String.format("₹%.2f", total));
        subtotalLabel = getLabelFromRow(subtotalRow);

        // Tax
        HBox taxRow = createSummaryRow("Tax (8%):", String.format("₹%.2f", tax));
        taxLabel = getLabelFromRow(taxRow);

        Separator separator2 = new Separator();

        // Grand Total
        HBox grandTotalRow = new HBox();
        grandTotalRow.setAlignment(Pos.CENTER);
        HBox.setHgrow(grandTotalRow, Priority.ALWAYS);

        Label grandTotalTitle = new Label("Total:");
        grandTotalTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 20));
        grandTotalTitle.setStyle("-fx-text-fill: white;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        grandTotalLabel = new Label(String.format("₹%.2f", grandTotal));
        grandTotalLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));
        grandTotalLabel.setStyle("-fx-text-fill: #778DA9;");

        grandTotalRow.getChildren().addAll(grandTotalTitle, spacer, grandTotalLabel);

        // Checkout Button
        Button checkoutButton = new Button("Proceed to Checkout");
        checkoutButton.setMaxWidth(Double.MAX_VALUE);
        checkoutButton.setStyle("-fx-background-color: #778DA9; -fx-text-fill: white; " +
                "-fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 15; " +
                "-fx-background-radius: 5; -fx-cursor: hand;");
        checkoutButton.setDisable(cartItems.isEmpty());

        checkoutButton.setOnMouseEntered(e -> {
            if (!checkoutButton.isDisabled()) {
                checkoutButton.setStyle("-fx-background-color: #8A9FBB; -fx-text-fill: white; " +
                        "-fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 15; " +
                        "-fx-background-radius: 5; -fx-cursor: hand;");
            }
        });

        checkoutButton.setOnMouseExited(e -> {
            if (!checkoutButton.isDisabled()) {
                checkoutButton.setStyle("-fx-background-color: #778DA9; -fx-text-fill: white; " +
                        "-fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 15; " +
                        "-fx-background-radius: 5; -fx-cursor: hand;");
            }
        });

        checkoutButton.setOnAction(e -> {
            try {
                orderService.placeOrder(user, cartItems);
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Success");
                alert.setHeaderText("Order Placed Successfully!");
                alert.setContentText(String.format("Total Amount: ₹%.2f\nThank you for your purchase!", grandTotal));
                alert.showAndWait();

                cartItems.clear();
                ((javafx.stage.Stage) summaryBox.getScene().getWindow()).close();
            } catch (Exception ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Failed to place order");
                alert.setContentText(ex.getMessage());
                alert.showAndWait();
            }
        });

        summaryBox.getChildren().addAll(summaryTitle, separator1, subtotalRow, taxRow,
                separator2, grandTotalRow, checkoutButton);
        return summaryBox;
    }

    private HBox createSummaryRow(String label, String value) {
        HBox row = new HBox();
        row.setAlignment(Pos.CENTER);
        HBox.setHgrow(row, Priority.ALWAYS);

        Label labelNode = new Label(label);
        labelNode.setStyle("-fx-text-fill: #aaa; -fx-font-size: 14px;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label valueNode = new Label(value);
        valueNode.setStyle("-fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold;");

        row.getChildren().addAll(labelNode, spacer, valueNode);
        return row;
    }

    private Label getLabelFromRow(HBox row) {
        // The value label is the last child (index 2: labelNode, spacer, valueNode)
        return (Label) row.getChildren().get(2);
    }

    private void refreshCart() {
        // Rebuild items container
        itemsContainer.getChildren().clear();

        if (cartItems.isEmpty()) {
            itemsContainer.getChildren().add(createEmptyCartView());
        } else {
            for (CartItem item : cartItems) {
                itemsContainer.getChildren().add(createCartItemCard(item));
            }
        }

        // Update summary
        double total = orderService.calculateTotal(cartItems);
        double tax = orderService.calculateTax(total);
        double grandTotal = total + tax;

        subtotalLabel.setText(String.format("₹%.2f", total));
        taxLabel.setText(String.format("₹%.2f", tax));
        grandTotalLabel.setText(String.format("₹%.2f", grandTotal));
    }
}
