package com.ecommerce.model;

public class Electronic extends Product {

    public Electronic(int id, String name, double price, int stock, String category, String brand) {
        super(id, name, category, price, stock, brand);
    }

    @Override
    public double getDiscount() {
        // 10% discount for general electronics
        return 0.10;
    }
}
