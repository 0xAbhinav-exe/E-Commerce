package com.ecommerce.gui;

import com.ecommerce.dao.UserDAO;
import com.ecommerce.exception.InvalidLoginException;
import com.ecommerce.model.User;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

public class LoginView {

    private UserDAO userDAO;

    public LoginView() {
        this.userDAO = new UserDAO();
    }

    public Parent getView() {
        VBox layout = new VBox(15);
        layout.setPadding(new Insets(40));
        layout.setAlignment(Pos.CENTER);
        layout.getStyleClass().add("login-container");
        layout.setMaxWidth(400);

        Label titleLabel = new Label("Welcome Back");
        titleLabel.getStyleClass().add("title-label");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        Button loginButton = new Button("Login");
        loginButton.setMaxWidth(Double.MAX_VALUE);

        Label messageLabel = new Label();
        messageLabel.getStyleClass().add("error-label");

        // Keyboard support for Login
        passwordField.setOnKeyPressed(e -> {
            if (e.getCode() == javafx.scene.input.KeyCode.ENTER) {
                loginButton.fire();
            }
        });

        loginButton.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();
            try {
                User user = userDAO.login(username, password);
                // Always show Dashboard first, even for Admins
                EcommerceApp.showDashboard(user);
            } catch (InvalidLoginException ex) {
                messageLabel.setText(ex.getMessage());

                // Shake Animation
                javafx.animation.TranslateTransition tt = new javafx.animation.TranslateTransition(
                        javafx.util.Duration.millis(50), layout);
                tt.setByX(10f);
                tt.setCycleCount(4);
                tt.setAutoReverse(true);
                tt.play();
            } catch (Exception ex) {
                ex.printStackTrace();
                String msg = ex.getMessage();
                if (ex.getCause() != null) {
                    msg += " -> " + ex.getCause().getMessage();
                }
                messageLabel.setText("Error: " + msg);
            }
        });

        Hyperlink registerLink = new Hyperlink("Create an account");
        registerLink.setOnAction(e -> {
            showRegisterDialog();
        });

        layout.getChildren().addAll(titleLabel, usernameField, passwordField, loginButton, registerLink, messageLabel);
        return layout;
    }

    private void showRegisterDialog() {
        Dialog<User> dialog = new Dialog<>();
        dialog.setTitle("Register");
        dialog.setHeaderText("Create a new account");

        ButtonType registerButtonType = new ButtonType("Register", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(registerButtonType, ButtonType.CANCEL);

        VBox content = new VBox(10);
        content.setPadding(new Insets(20));

        TextField username = new TextField();
        username.setPromptText("Username");
        PasswordField password = new PasswordField();
        password.setPromptText("Password");
        ComboBox<String> role = new ComboBox<>();
        role.getItems().addAll("CUSTOMER", "ADMIN");
        role.setValue("CUSTOMER");

        content.getChildren().addAll(new Label("Username:"), username, new Label("Password:"), password,
                new Label("Role:"), role);
        dialog.getDialogPane().setContent(content);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == registerButtonType) {
                userDAO.register(username.getText(), password.getText(), role.getValue());
                return null;
            }
            return null;
        });

        dialog.showAndWait();
    }
}
