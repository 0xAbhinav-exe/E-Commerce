-- E-Commerce Database Setup Script
-- Run this script in MySQL to set up the database

-- Create database
CREATE DATABASE IF NOT EXISTS ecommerce_db;
USE ecommerce_db;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL,
    price DOUBLE NOT NULL,
    stock INTEGER NOT NULL,
    brand VARCHAR(100),
    attributes TEXT
);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    user_id INTEGER NOT NULL,
    total_amount DOUBLE NOT NULL,
    order_date VARCHAR(50) NOT NULL,
    status VARCHAR(50) DEFAULT 'Pending',
    FOREIGN KEY(user_id) REFERENCES users(id)
);

-- Order items table
CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    price_at_purchase DOUBLE NOT NULL,
    FOREIGN KEY(order_id) REFERENCES orders(id),
    FOREIGN KEY(product_id) REFERENCES products(id)
);

-- Insert default users
INSERT IGNORE INTO users (username, password, role) VALUES ('admin', 'admin123', 'ADMIN');
INSERT IGNORE INTO users (username, password, role) VALUES ('customer', 'customer123', 'CUSTOMER');

-- Insert sample products
INSERT INTO products (name, category, price, stock, brand, attributes) VALUES 
('Gaming Laptop', 'Electronic', 1200.00, 10, 'Alienware', 'High Performance'),
('iPhone 15', 'SmartDevice', 999.00, 20, 'Apple', '5G, A16 Bionic'),
('Wireless Earbuds', 'Accessory', 199.00, 50, 'Sony', 'Noise Cancelling'),
('4K Monitor', 'Electronic', 300.00, 15, 'Dell', '27 inch'),
('Smart Watch', 'SmartDevice', 250.00, 30, 'Samsung', 'Water Resistant');

-- Verify setup
SELECT 'Database setup complete!' AS Status;
SELECT COUNT(*) AS UserCount FROM users;
SELECT COUNT(*) AS ProductCount FROM products;
