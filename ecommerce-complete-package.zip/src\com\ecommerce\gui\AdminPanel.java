package com.ecommerce.gui;

import com.ecommerce.dao.ProductDAO;
import com.ecommerce.dao.OrderDAO;
import com.ecommerce.model.*;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AdminPanel {

    private ProductDAO productDAO;
    private OrderDAO orderDAO;

    public AdminPanel() {
        this.productDAO = new ProductDAO();
        this.orderDAO = new OrderDAO();
    }

    public Parent getView() {
        VBox layout = new VBox(15);
        layout.setPadding(new Insets(20));
        layout.setStyle("-fx-background-color: #0D1B2A;");

        Label title = new Label("Admin Panel");
        title.getStyleClass().add("title-label");

        TabPane tabPane = new TabPane();

        // Tab 1: Add Product
        Tab addTab = new Tab("Add Product");
        addTab.setClosable(false);

        VBox addLayout = new VBox(15);
        addLayout.setPadding(new Insets(20));

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        TextField idField = new TextField();
        idField.setPromptText("ID (Optional)");
        TextField nameField = new TextField();
        TextField priceField = new TextField();
        TextField stockField = new TextField();
        TextField brandField = new TextField();
        TextField extraField = new TextField(); // Connectivity or Compatibility
        TextField imagePathField = new TextField();
        imagePathField.setPromptText("assets/default.png");

        ComboBox<String> categoryBox = new ComboBox<>();
        categoryBox.getItems().addAll("Electronic", "SmartDevice", "Accessory");
        categoryBox.setValue("Electronic");

        grid.addRow(0, new Label("ID (Optional):"), idField);
        grid.addRow(1, new Label("Name:"), nameField);
        grid.addRow(2, new Label("Category:"), categoryBox);
        grid.addRow(3, new Label("Price:"), priceField);
        grid.addRow(4, new Label("Stock:"), stockField);
        grid.addRow(5, new Label("Brand:"), brandField);
        grid.addRow(6, new Label("Extra (Wifi/Compat):"), extraField);
        grid.addRow(7, new Label("Image Path:"), imagePathField);

        Button addButton = new Button("Add Product");
        addButton.setOnAction(e -> {
            try {
                int id = 0;
                if (!idField.getText().isEmpty()) {
                    id = Integer.parseInt(idField.getText());
                }
                String name = nameField.getText();
                String cat = categoryBox.getValue();
                double price = Double.parseDouble(priceField.getText());
                int stock = Integer.parseInt(stockField.getText());
                String brand = brandField.getText();
                String extra = extraField.getText();
                String imgPath = imagePathField.getText();

                Product p;
                if ("SmartDevice".equals(cat)) {
                    p = new SmartDevice(id, name, price, stock, cat, brand, extra);
                } else if ("Accessory".equals(cat)) {
                    p = new Accessory(id, name, price, stock, cat, brand, extra);
                } else {
                    p = new Electronic(id, name, price, stock, cat, brand);
                }

                if (imgPath != null && !imgPath.trim().isEmpty()) {
                    p.setImagePath(imgPath);
                }

                productDAO.addProduct(p);
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Product Added!");
                alert.showAndWait();

                // Clear fields
                idField.clear();
                nameField.clear();
                priceField.clear();
                stockField.clear();
                brandField.clear();
                extraField.clear();
                imagePathField.clear();

            } catch (Exception ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Error: " + ex.getMessage());
                alert.showAndWait();
            }
        });

        addLayout.getChildren().addAll(grid, addButton);
        addTab.setContent(addLayout);

        // Tab 2: Delete Product (Enhanced)
        Tab deleteTab = new Tab("Delete Product");
        deleteTab.setClosable(false);

        VBox deleteLayout = new VBox(15);
        deleteLayout.setPadding(new Insets(20));

        TextField deleteIdField = new TextField();
        deleteIdField.setPromptText("Enter Product ID to Delete");

        TextArea deleteDetailsArea = new TextArea();
        deleteDetailsArea.setEditable(false);
        deleteDetailsArea.setPrefHeight(100);
        deleteDetailsArea.setPromptText("Product details will appear here...");

        Button searchDeleteButton = new Button("Search to Verify");
        Button deleteButton = new Button("Delete Product");
        deleteButton.getStyleClass().add("danger-button");
        deleteButton.setDisable(true);

        searchDeleteButton.setOnAction(e -> {
            try {
                int id = Integer.parseInt(deleteIdField.getText());
                Product p = productDAO.getProductById(id);
                if (p != null) {
                    deleteDetailsArea.setText("Found: " + p.getName() + " (" + p.getCategory() + ")");
                    deleteButton.setDisable(false);
                } else {
                    deleteDetailsArea.setText("Product not found.");
                    deleteButton.setDisable(true);
                }
            } catch (Exception ex) {
                deleteDetailsArea.setText("Error: " + ex.getMessage());
            }
        });

        deleteButton.setOnAction(e -> {
            try {
                int id = Integer.parseInt(deleteIdField.getText());
                productDAO.deleteProduct(id);
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Product Deleted!");
                alert.showAndWait();
                deleteIdField.clear();
                deleteDetailsArea.clear();
                deleteButton.setDisable(true);
            } catch (Exception ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Error: " + ex.getMessage());
                alert.showAndWait();
            }
        });

        // Keyboard support for Delete
        deleteIdField.setOnKeyPressed(e -> {
            if (e.getCode() == javafx.scene.input.KeyCode.ENTER) {
                searchDeleteButton.fire();
            }
        });

        deleteLayout.getChildren().addAll(new Label("Delete Product by ID"), deleteIdField, searchDeleteButton,
                deleteDetailsArea, deleteButton);
        deleteTab.setContent(deleteLayout);

        // Tab 3: Modify Product (Versatile)
        Tab modifyTab = new Tab("Modify Product");
        modifyTab.setClosable(false);

        VBox modifyLayout = new VBox(15);
        modifyLayout.setPadding(new Insets(20));

        TextField searchModifyIdField = new TextField();
        searchModifyIdField.setPromptText("Enter Product ID to Modify");
        Button searchModifyButton = new Button("Load Product");

        // Edit Fields
        TextField editName = new TextField();
        TextField editPrice = new TextField();
        TextField editStock = new TextField();
        TextField editBrand = new TextField();
        TextField editExtra = new TextField();
        TextField editImagePath = new TextField();
        ComboBox<String> editCategory = new ComboBox<>();
        editCategory.getItems().addAll("Electronic", "SmartDevice", "Accessory");

        GridPane editGrid = new GridPane();
        editGrid.setHgap(10);
        editGrid.setVgap(10);
        editGrid.addRow(0, new Label("Name:"), editName);
        editGrid.addRow(1, new Label("Category:"), editCategory);
        editGrid.addRow(2, new Label("Price:"), editPrice);
        editGrid.addRow(3, new Label("Stock:"), editStock);
        editGrid.addRow(4, new Label("Brand:"), editBrand);
        editGrid.addRow(5, new Label("Extra:"), editExtra);
        editGrid.addRow(6, new Label("Image Path:"), editImagePath);

        Button updateButton = new Button("Save Changes");
        updateButton.setDisable(true);

        searchModifyButton.setOnAction(e -> {
            try {
                int id = Integer.parseInt(searchModifyIdField.getText());
                Product p = productDAO.getProductById(id);
                if (p != null) {
                    editName.setText(p.getName());
                    editCategory.setValue(p.getCategory());
                    editPrice.setText(String.valueOf(p.getPrice()));
                    editStock.setText(String.valueOf(p.getStock()));
                    editImagePath.setText(p.getImagePath());

                    if (p instanceof Electronic)
                        editBrand.setText(((Electronic) p).getBrand());
                    if (p instanceof SmartDevice)
                        editExtra.setText(((SmartDevice) p).getConnectivity());
                    else if (p instanceof Accessory)
                        editExtra.setText(((Accessory) p).getCompatibility());
                    else
                        editExtra.clear();

                    updateButton.setDisable(false);
                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING, "Product not found");
                    alert.showAndWait();
                    updateButton.setDisable(true);
                }
            } catch (Exception ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Error: " + ex.getMessage());
                alert.showAndWait();
            }
        });

        // Keyboard support for Search
        searchModifyIdField.setOnKeyPressed(e -> {
            if (e.getCode() == javafx.scene.input.KeyCode.ENTER) {
                searchModifyButton.fire();
            }
        });

        updateButton.setOnAction(e -> {
            try {
                int id = Integer.parseInt(searchModifyIdField.getText());
                String name = editName.getText();
                String cat = editCategory.getValue();
                double price = Double.parseDouble(editPrice.getText());
                int stock = Integer.parseInt(editStock.getText());
                String brand = editBrand.getText();
                String extra = editExtra.getText();
                String imgPath = editImagePath.getText();

                Product p;
                if ("SmartDevice".equals(cat)) {
                    p = new SmartDevice(id, name, price, stock, cat, brand, extra);
                } else if ("Accessory".equals(cat)) {
                    p = new Accessory(id, name, price, stock, cat, brand, extra);
                } else {
                    p = new Electronic(id, name, price, stock, cat, brand);
                }

                if (imgPath != null && !imgPath.trim().isEmpty()) {
                    p.setImagePath(imgPath);
                }

                productDAO.updateProduct(p);
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Product Saved Successfully!");
                alert.showAndWait();

            } catch (Exception ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Error: " + ex.getMessage());
                alert.showAndWait();
            }
        });

        // Keyboard support for Save
        javafx.event.EventHandler<javafx.scene.input.KeyEvent> saveHandler = e -> {
            if (e.getCode() == javafx.scene.input.KeyCode.ENTER) {
                updateButton.fire();
            }
        };
        editName.setOnKeyPressed(saveHandler);
        editPrice.setOnKeyPressed(saveHandler);
        editStock.setOnKeyPressed(saveHandler);
        editBrand.setOnKeyPressed(saveHandler);
        editExtra.setOnKeyPressed(saveHandler);
        editCategory.setOnKeyPressed(saveHandler);

        modifyLayout.getChildren().addAll(
                new Label("Step 1: Search Product"),
                searchModifyIdField, searchModifyButton,
                new Separator(),
                new Label("Step 2: Modify Details"),
                editGrid, updateButton);
        modifyTab.setContent(modifyLayout);

        // Tab 4: View Products
        Tab viewTab = new Tab("View Products");
        viewTab.setClosable(false);

        VBox viewLayout = new VBox(15);
        viewLayout.setPadding(new Insets(20));

        TableView<Product> productTable = new TableView<>();

        TableColumn<Product, Integer> colId = new TableColumn<>("ID");
        colId.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("id"));

        TableColumn<Product, String> colName = new TableColumn<>("Name");
        colName.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("name"));

        TableColumn<Product, String> colCat = new TableColumn<>("Category");
        colCat.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("category"));

        TableColumn<Product, Double> colPrice = new TableColumn<>("Price");
        colPrice.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("price"));

        TableColumn<Product, Integer> colStock = new TableColumn<>("Stock");
        colStock.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("stock"));

        TableColumn<Product, String> colBrand = new TableColumn<>("Brand");
        colBrand.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("brand"));

        productTable.getColumns().addAll(colId, colName, colCat, colPrice, colStock, colBrand);

        Button refreshButton = new Button("Refresh List");
        refreshButton.setOnAction(e -> {
            try {
                productTable.getItems().setAll(productDAO.getAllProducts());
            } catch (Exception ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Error loading products: " + ex.getMessage());
                alert.showAndWait();
            }
        });

        // Initial Load
        refreshButton.fire();

        viewLayout.getChildren().addAll(refreshButton, productTable);
        viewTab.setContent(viewLayout);

        tabPane.getTabs().addAll(addTab, deleteTab, modifyTab, viewTab, createOrderManagementTab());

        layout.getChildren().addAll(title, tabPane);

        ScrollPane scrollPane = new ScrollPane(layout);
        scrollPane.setFitToWidth(true);
        return scrollPane;
    }

    private Tab createOrderManagementTab() {
        Tab orderTab = new Tab("Order Management");
        orderTab.setClosable(false);

        VBox orderLayout = new VBox(15);
        orderLayout.setPadding(new Insets(20));

        Label headerLabel = new Label("Manage Customer Orders");
        headerLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #778DA9;");

        // Filter by status
        javafx.scene.layout.HBox filterBox = new javafx.scene.layout.HBox(10);
        filterBox.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
        Label filterLabel = new Label("Filter by Status:");
        filterLabel.setStyle("-fx-text-fill: #E0E1DD;");
        ComboBox<String> statusFilter = new ComboBox<>();
        statusFilter.getItems().addAll("All", "Pending", "Processing", "Shipped", "Delivered", "Cancelled");
        statusFilter.setValue("All");
        filterBox.getChildren().addAll(filterLabel, statusFilter);

        // Orders Table
        TableView<com.ecommerce.model.Order> orderTable = new TableView<>();

        TableColumn<com.ecommerce.model.Order, Integer> colOrderId = new TableColumn<>("Order ID");
        colOrderId.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("id"));
        colOrderId.setPrefWidth(80);

        TableColumn<com.ecommerce.model.Order, String> colCustomer = new TableColumn<>("Customer");
        colCustomer.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("username"));
        colCustomer.setPrefWidth(120);

        TableColumn<com.ecommerce.model.Order, String> colDate = new TableColumn<>("Date");
        colDate.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("orderDate"));
        colDate.setPrefWidth(100);

        TableColumn<com.ecommerce.model.Order, Double> colTotal = new TableColumn<>("Total (₹)");
        colTotal.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("totalAmount"));
        colTotal.setPrefWidth(100);

        TableColumn<com.ecommerce.model.Order, String> colStatus = new TableColumn<>("Status");
        colStatus.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("status"));
        colStatus.setPrefWidth(120);

        orderTable.getColumns().addAll(colOrderId, colCustomer, colDate, colTotal, colStatus);

        // Buttons
        javafx.scene.layout.HBox buttonBox = new javafx.scene.layout.HBox(10);
        Button refreshOrdersBtn = new Button("Refresh Orders");
        Button viewDetailsBtn = new Button("View Details");
        Button updateStatusBtn = new Button("Update Status");
        updateStatusBtn.getStyleClass().add("success-button");

        buttonBox.getChildren().addAll(refreshOrdersBtn, viewDetailsBtn, updateStatusBtn);

        // Load orders function
        Runnable loadOrders = () -> {
            try {
                java.util.List<com.ecommerce.model.Order> orders = orderDAO.getAllOrders();
                String filter = statusFilter.getValue();
                if (!"All".equals(filter)) {
                    orders = orders.stream()
                            .filter(o -> filter.equalsIgnoreCase(o.getStatus()))
                            .collect(java.util.stream.Collectors.toList());
                }
                orderTable.getItems().setAll(orders);
            } catch (Exception ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Error loading orders: " + ex.getMessage());
                alert.showAndWait();
            }
        };

        // Refresh button action
        refreshOrdersBtn.setOnAction(e -> loadOrders.run());
        statusFilter.setOnAction(e -> loadOrders.run());

        // View Details button
        viewDetailsBtn.setOnAction(e -> {
            com.ecommerce.model.Order selected = orderTable.getSelectionModel().getSelectedItem();
            if (selected != null) {
                showOrderDetailsDialog(selected);
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Please select an order first.");
                alert.showAndWait();
            }
        });

        // Update Status button
        updateStatusBtn.setOnAction(e -> {
            com.ecommerce.model.Order selected = orderTable.getSelectionModel().getSelectedItem();
            if (selected != null) {
                showUpdateStatusDialog(selected, loadOrders);
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Please select an order first.");
                alert.showAndWait();
            }
        });

        // Initial load
        loadOrders.run();

        orderLayout.getChildren().addAll(headerLabel, filterBox, orderTable, buttonBox);
        orderTab.setContent(orderLayout);
        return orderTab;
    }

    private void showOrderDetailsDialog(com.ecommerce.model.Order order) {
        Alert dialog = new Alert(Alert.AlertType.INFORMATION);
        dialog.setTitle("Order Details");
        dialog.setHeaderText("Order #" + order.getId() + " - " + order.getUsername());

        StringBuilder details = new StringBuilder();
        details.append("Date: ").append(order.getOrderDate()).append("\n");
        details.append("Status: ").append(order.getStatus()).append("\n");
        details.append("Total: ₹").append(String.format("%.2f", order.getTotalAmount())).append("\n\n");
        details.append("Items:\n");
        details.append("-".repeat(40)).append("\n");

        for (com.ecommerce.model.OrderItem item : order.getOrderItems()) {
            details.append(item.getProductName())
                    .append(" x").append(item.getQuantity())
                    .append(" @ ₹").append(String.format("%.2f", item.getPriceAtPurchase()))
                    .append(" = ₹").append(String.format("%.2f", item.getSubtotal()))
                    .append("\n");
        }

        dialog.setContentText(details.toString());
        dialog.showAndWait();
    }

    private void showUpdateStatusDialog(com.ecommerce.model.Order order, Runnable refreshCallback) {
        Dialog<String> dialog = new Dialog<>();
        dialog.setTitle("Update Order Status");
        dialog.setHeaderText("Order #" + order.getId() + " - Current Status: " + order.getStatus());

        ComboBox<String> statusCombo = new ComboBox<>();
        statusCombo.getItems().addAll("Pending", "Processing", "Shipped", "Delivered", "Cancelled");
        statusCombo.setValue(order.getStatus());

        VBox content = new VBox(10);
        content.getChildren().addAll(new Label("Select new status:"), statusCombo);
        dialog.getDialogPane().setContent(content);

        ButtonType updateButtonType = new ButtonType("Update", javafx.scene.control.ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(updateButtonType, ButtonType.CANCEL);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == updateButtonType) {
                return statusCombo.getValue();
            }
            return null;
        });

        dialog.showAndWait().ifPresent(newStatus -> {
            try {
                orderDAO.updateOrderStatus(order.getId(), newStatus);
                Alert success = new Alert(Alert.AlertType.INFORMATION, "Order status updated to: " + newStatus);
                success.showAndWait();
                refreshCallback.run();
            } catch (Exception ex) {
                Alert error = new Alert(Alert.AlertType.ERROR, "Error updating status: " + ex.getMessage());
                error.showAndWait();
            }
        });
    }

    public static void show() {
        AdminPanel panel = new AdminPanel();
        Stage stage = new Stage();
        stage.setTitle("Admin Panel");
        Scene scene = new Scene(panel.getView(), 500, 600);
        scene.getStylesheets().add(EcommerceApp.class.getResource("/styles.css").toExternalForm());
        stage.setScene(scene);
        stage.show();
    }
}
