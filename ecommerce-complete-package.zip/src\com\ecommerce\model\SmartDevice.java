package com.ecommerce.model;

public class SmartDevice extends Electronic {
    private String connectivity;

    public SmartDevice(int id, String name, double price, int stock, String brand, String connectivity,
            String imagePath) {
        super(id, name, price, stock, brand, imagePath);
        this.connectivity = connectivity;
    }

    public String getConnectivity() {
        return connectivity;
    }

    @Override
    public double getDiscount() {
        // 15% discount for smart devices (High demand)
        return 0.15;
    }
}
