package com.ecommerce.util;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.SQLException;

public class DatabaseInitializer {

    public static void initialize() {
        String createUsersTable = "CREATE TABLE IF NOT EXISTS users (" +
                "id INTEGER PRIMARY KEY AUTO_INCREMENT," +
                "username VARCHAR(255) UNIQUE NOT NULL," +
                "password VARCHAR(255) NOT NULL," +
                "role VARCHAR(50) NOT NULL" + // 'ADMIN' or 'CUSTOMER'
                ");";

        String createProductsTable = "CREATE TABLE IF NOT EXISTS products (" +
                "id INTEGER PRIMARY KEY AUTO_INCREMENT," +
                "name VARCHAR(255) NOT NULL," +
                "category VARCHAR(100) NOT NULL," +
                "price DOUBLE NOT NULL," +
                "stock INTEGER NOT NULL," +
                "brand VARCHAR(100)," +
                "attributes TEXT" + // JSON or comma-separated specific attributes
                ");";

        String createOrdersTable = "CREATE TABLE IF NOT EXISTS orders (" +
                "id INTEGER PRIMARY KEY AUTO_INCREMENT," +
                "user_id INTEGER NOT NULL," +
                "total_amount DOUBLE NOT NULL," +
                "order_date VARCHAR(50) NOT NULL," +
                "status VARCHAR(50) DEFAULT 'Pending'," +
                "FOREIGN KEY(user_id) REFERENCES users(id)" +
                ");";

        String createOrderItemsTable = "CREATE TABLE IF NOT EXISTS order_items (" +
                "id INTEGER PRIMARY KEY AUTO_INCREMENT," +
                "order_id INTEGER NOT NULL," +
                "product_id INTEGER NOT NULL," +
                "quantity INTEGER NOT NULL," +
                "price_at_purchase DOUBLE NOT NULL," +
                "FOREIGN KEY(order_id) REFERENCES orders(id)," +
                "FOREIGN KEY(product_id) REFERENCES products(id)" +
                ");";

        try (Connection conn = DBConnection.getConnection();
                Statement stmt = conn.createStatement()) {

            stmt.execute(createUsersTable);
            stmt.execute(createProductsTable);
            stmt.execute(createOrdersTable);
            stmt.execute(createOrderItemsTable);

            // Add status column to existing orders table if it doesn't exist
            try {
                String addStatusColumn = "ALTER TABLE orders ADD COLUMN status VARCHAR(50) DEFAULT 'Pending'";
                stmt.execute(addStatusColumn);
            } catch (SQLException e) {
                // Column might already exist (error code 1060), ignore
                if (!e.getMessage().contains("Duplicate column")) {
                    System.err.println("Warning: Could not add status column: " + e.getMessage());
                }
            }

            System.out.println("Database tables initialized.");

            // Seed Admin User if not exists
            // In a real app, password should be hashed. For this academic project, simple
            // text might be used or simple hash.
            // We will handle seeding in the DAO or a separate seeder if needed, but let's
            // put a default admin here.
            // Seed Admin User
            String seedAdmin = "INSERT IGNORE INTO users (username, password, role) VALUES ('admin', 'admin123', 'ADMIN')";
            stmt.execute(seedAdmin);

            // Seed Customer User
            String seedCustomer = "INSERT IGNORE INTO users (username, password, role) VALUES ('customer', 'customer123', 'CUSTOMER')";
            stmt.execute(seedCustomer);

            // Seed Sample Products
            String checkProducts = "SELECT COUNT(*) FROM products";
            try (java.sql.ResultSet rs = stmt.executeQuery(checkProducts)) {
                if (rs.next() && rs.getInt(1) == 0) {
                    String p1 = "INSERT INTO products (name, category, price, stock, brand, attributes) VALUES ('Gaming Laptop', 'Electronic', 1200.00, 10, 'Alienware', 'High Performance')";
                    String p2 = "INSERT INTO products (name, category, price, stock, brand, attributes) VALUES ('iPhone 15', 'SmartDevice', 999.00, 20, 'Apple', '5G, A16 Bionic')";
                    String p3 = "INSERT INTO products (name, category, price, stock, brand, attributes) VALUES ('Wireless Earbuds', 'Accessory', 199.00, 50, 'Sony', 'Noise Cancelling')";
                    String p4 = "INSERT INTO products (name, category, price, stock, brand, attributes) VALUES ('4K Monitor', 'Electronic', 300.00, 15, 'Dell', '27 inch')";
                    String p5 = "INSERT INTO products (name, category, price, stock, brand, attributes) VALUES ('Smart Watch', 'SmartDevice', 250.00, 30, 'Samsung', 'Water Resistant')";

                    stmt.execute(p1);
                    stmt.execute(p2);
                    stmt.execute(p3);
                    stmt.execute(p4);
                    stmt.execute(p5);
                    System.out.println("Sample products seeded.");
                }
            }

        } catch (SQLException e) {
            System.err.println("Database initialization failed: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        initialize();
    }
}
