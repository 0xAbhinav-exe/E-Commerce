# 🚀 Quick Setup Guide

## For Someone Downloading This Project

### Step 1: Install Prerequisites

1. **Java JDK 17+**
   - Download: https://www.oracle.com/java/technologies/downloads/
   - Install and verify: `java -version`

2. **JavaFX SDK 25.0.1**
   - Download: https://gluonhq.com/products/javafx/
   - Extract to a folder (e.g., `C:\javafx-sdk-25.0.1`)

3. **MySQL Server 8.0+**
   - Download: https://dev.mysql.com/downloads/mysql/
   - Install and remember your root password

4. **MySQL Connector/J**
   - Download: https://dev.mysql.com/downloads/connector/j/
   - Extract the JAR file (e.g., `mysql-connector-j-9.3.0.jar`)

### Step 2: Set Up Database

1. Open MySQL Command Line or MySQL Workbench
2. Run the `database_setup.sql` file:
   ```sql
   source /path/to/database_setup.sql
   ```
   OR copy-paste the contents into MySQL

### Step 3: Configure Database Connection

Edit `src/com/ecommerce/util/DBConnection.java`:
```java
private static final String URL = "jdbc:mysql://localhost:3306/ecommerce_db";
private static final String USER = "root";
private static final String PASSWORD = "YOUR_MYSQL_PASSWORD"; // Change this!
```

### Step 4: Compile the Project

```bash
javac -d bin -cp "path/to/mysql-connector-j-9.3.0.jar;path/to/javafx-sdk/lib/*" \
  --module-path "path/to/javafx-sdk/lib" \
  --add-modules javafx.controls,javafx.fxml \
  src/com/ecommerce/**/*.java
```

### Step 5: Copy Resources

```bash
# Copy styles.css to bin folder
copy src\styles.css bin\
```

### Step 6: Run the Application

```bash
java -cp "bin;path/to/mysql-connector-j-9.3.0.jar" \
  --module-path "path/to/javafx-sdk/lib" \
  --add-modules javafx.controls,javafx.fxml \
  com.ecommerce.gui.EcommerceApp
```

## Default Login Credentials

- **Admin**: `admin` / `admin123`
- **Customer**: `customer` / `customer123`

## Troubleshooting

- **"Module javafx.controls not found"**: Check JavaFX SDK path
- **"ClassNotFoundException: com.mysql.cj.jdbc.Driver"**: Check MySQL Connector path
- **"Access denied for user"**: Update password in DBConnection.java
- **"Database does not exist"**: Run database_setup.sql first

## Project Structure

```
E Commerce/
├── src/
│   ├── com/ecommerce/
│   │   ├── dao/          # Database access
│   │   ├── gui/          # UI components
│   │   ├── model/        # Data models
│   │   ├── service/      # Business logic
│   │   ├── util/         # Utilities
│   │   └── exception/    # Custom exceptions
│   └── styles.css        # Application styling
├── database_setup.sql    # Database initialization
└── README.md            # Full documentation
```

## Need Help?

Check the main README.md for detailed documentation and features.
