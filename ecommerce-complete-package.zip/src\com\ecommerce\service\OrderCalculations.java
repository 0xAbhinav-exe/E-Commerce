package com.ecommerce.service;

import com.ecommerce.model.CartItem;
import java.util.List;

public interface OrderCalculations {
    double calculateTotal(List<CartItem> items);

    double calculateTax(double amount);
}
