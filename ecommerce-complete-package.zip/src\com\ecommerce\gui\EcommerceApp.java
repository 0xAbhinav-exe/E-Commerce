package com.ecommerce.gui;

import com.ecommerce.util.DatabaseInitializer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class EcommerceApp extends Application {

    private static Stage primaryStage;
    private static com.ecommerce.model.User currentUser;

    @Override
    public void start(Stage stage) {
        primaryStage = stage;
        primaryStage.setTitle("Electronics E-Commerce System");

        // Initialize DB on start
        DatabaseInitializer.initialize();

        // Show Login Screen
        showLoginScreen();

        primaryStage.show();
    }

    public static void showLoginScreen() {
        LoginView loginView = new LoginView();
        Scene scene = new Scene(loginView.getView(), 400, 500);
        applyStyles(scene);
        primaryStage.setScene(scene);
        primaryStage.centerOnScreen();
    }

    public static void showDashboard(com.ecommerce.model.User user) {
        currentUser = user;
        DashboardView dashboard = new DashboardView(user);
        Scene scene = new Scene(dashboard.getView(), 1000, 700);
        applyStyles(scene);
        primaryStage.setScene(scene);
        primaryStage.centerOnScreen();
    }

    private static void applyStyles(Scene scene) {
        java.net.URL cssResource = EcommerceApp.class.getResource("/styles.css");
        if (cssResource != null) {
            scene.getStylesheets().add(cssResource.toExternalForm());
        } else {
            System.err.println("Warning: styles.css not found.");
        }
    }

    public static com.ecommerce.model.User getCurrentUser() {
        return currentUser;
    }

    public static Stage getPrimaryStage() {
        return primaryStage;
    }

    public static void logout() {
        currentUser = null;
        showLoginScreen();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
