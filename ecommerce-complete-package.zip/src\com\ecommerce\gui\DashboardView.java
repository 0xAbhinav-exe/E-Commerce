package com.ecommerce.gui;

import com.ecommerce.dao.ProductDAO;
import com.ecommerce.model.CartItem;
import com.ecommerce.model.Product;
import com.ecommerce.model.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class DashboardView {

    private User user;
    private ProductDAO productDAO;
    private ObservableList<Product> productList;
    private List<CartItem> cart;
    private Button cartButton;

    public DashboardView(User user) {
        this.user = user;
        this.productDAO = new ProductDAO();
        this.productList = FXCollections.observableArrayList();
        this.cart = new ArrayList<>();
    }

    public Parent getView() {
        BorderPane root = new BorderPane();

        // Top Bar
        HBox topBar = new HBox(20);
        topBar.setPadding(new Insets(15));
        topBar.getStyleClass().add("top-bar");
        topBar.setAlignment(Pos.CENTER_LEFT);

        Label welcomeLabel = new Label("Welcome, " + user.getUsername());
        welcomeLabel.getStyleClass().add("welcome-label");

        cartButton = new Button("Cart (" + cart.size() + ")");
        cartButton.getStyleClass().add("nav-button");
        cartButton.setOnAction(e -> showCart());

        Button logoutButton = new Button("Logout");
        logoutButton.getStyleClass().add("nav-button");
        logoutButton.setOnAction(e -> EcommerceApp.logout());

        Region spacer = new Region();
        HBox.setHgrow(spacer, javafx.scene.layout.Priority.ALWAYS);

        topBar.getChildren().addAll(welcomeLabel, spacer);

        if ("ADMIN".equalsIgnoreCase(user.getRole())) {
            Button adminButton = new Button("Admin Panel");
            adminButton.getStyleClass().add("nav-button");
            adminButton.setOnAction(e -> AdminPanel.show());
            topBar.getChildren().add(adminButton);
        }

        Button refreshButton = new Button("Refresh");
        refreshButton.getStyleClass().add("nav-button");
        refreshButton.setOnAction(e -> loadProducts());

        Button myOrdersButton = new Button("📦 My Orders");
        myOrdersButton.getStyleClass().add("nav-button");
        myOrdersButton.setOnAction(e -> showOrderHistory());

        topBar.getChildren().addAll(refreshButton, myOrdersButton, cartButton, logoutButton);
        root.setTop(topBar);

        // Center - Product Grid
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color: transparent; -fx-background: transparent;");

        GridPane grid = new GridPane();
        grid.getStyleClass().add("grid-pane");
        grid.setAlignment(Pos.TOP_CENTER);

        // Bind grid content to productList
        javafx.collections.ListChangeListener<Product> listener = c -> {
            grid.getChildren().clear();
            int col = 0;
            int row = 0;
            for (Product p : productList) {
                grid.add(createProductCard(p), col, row);
                col++;
                if (col == 3) { // 3 Products per row
                    col = 0;
                    row++;
                }
            }
        };
        productList.addListener(listener);

        scrollPane.setContent(grid);
        root.setCenter(scrollPane);

        // Load Data in Background
        loadProducts();

        return root;
    }

    private VBox createProductCard(Product p) {
        VBox card = new VBox(10);
        card.getStyleClass().add("product-card");
        card.setAlignment(Pos.CENTER_LEFT);

        // Image View
        javafx.scene.image.ImageView imageView = new javafx.scene.image.ImageView();
        try {
            String imagePath = p.getImagePath();
            if (imagePath != null && !imagePath.isEmpty()) {
                // Try loading from classpath first
                String path = "/" + imagePath;
                java.net.URL imgUrl = getClass().getResource(path);

                if (imgUrl != null) {
                    javafx.scene.image.Image image = new javafx.scene.image.Image(imgUrl.toExternalForm());
                    imageView.setImage(image);
                } else {
                    // Try loading from file system as fallback
                    File imgFile = new File("bin/" + imagePath);
                    if (imgFile.exists()) {
                        javafx.scene.image.Image image = new javafx.scene.image.Image(imgFile.toURI().toString());
                        imageView.setImage(image);
                    } else {
                        // Load default image
                        java.net.URL defaultUrl = getClass().getResource("/assets/default.png");
                        if (defaultUrl != null) {
                            javafx.scene.image.Image defaultImage = new javafx.scene.image.Image(
                                    defaultUrl.toExternalForm());
                            imageView.setImage(defaultImage);
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading image for " + p.getName() + ": " + e.getMessage());
            e.printStackTrace();
        }
        imageView.setFitHeight(150);
        imageView.setFitWidth(200);
        imageView.setPreserveRatio(true);

        Label nameLabel = new Label(p.getName());
        nameLabel.getStyleClass().add("product-title");

        Label brandLabel = new Label(p.getBrand());
        brandLabel.getStyleClass().add("product-brand");

        Label priceLabel = new Label(String.format("₹%.2f", p.getPrice()));
        priceLabel.getStyleClass().add("product-price");

        Label stockLabel = new Label();
        if ("ADMIN".equalsIgnoreCase(user.getRole())) {
            // Admin sees exact stock
            stockLabel.setText("Stock: " + p.getStock());
            if (p.getStock() > 0) {
                stockLabel.getStyleClass().add("stock-in");
            } else {
                stockLabel.getStyleClass().add("stock-out");
            }
        } else {
            // Customer sees In/Out of Stock
            if (p.getStock() > 0) {
                stockLabel.setText("In Stock");
                stockLabel.getStyleClass().add("stock-in");
            } else {
                stockLabel.setText("Out of Stock");
                stockLabel.getStyleClass().add("stock-out");
            }
        }

        Button addToCartBtn = new Button("Add to Cart");
        addToCartBtn.getStyleClass().add("success-button");
        addToCartBtn.setMaxWidth(Double.MAX_VALUE);

        if (p.getStock() <= 0) {
            addToCartBtn.setDisable(true);
            addToCartBtn.setText("Unavailable");
        } else {
            addToCartBtn.setOnAction(e -> {
                addToCart(p);
            });
        }

        card.getChildren().addAll(imageView, nameLabel, brandLabel, priceLabel, stockLabel, addToCartBtn);
        return card;
    }

    private void loadProducts() {
        Task<List<Product>> task = new Task<>() {
            @Override
            protected List<Product> call() throws Exception {
                // Simulate network delay
                Thread.sleep(1000);
                return productDAO.getAllProducts();
            }
        };

        task.setOnSucceeded(e -> {
            productList.setAll(task.getValue());
        });

        task.setOnFailed(e -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Could not load products");
            alert.setContentText(task.getException().getMessage());
            alert.showAndWait();
        });

        new Thread(task).start();
    }

    private synchronized void addToCart(Product p) {
        // Check if already in cart
        for (CartItem item : cart) {
            if (item.getProduct().getId() == p.getId()) {
                item.setQuantity(item.getQuantity() + 1);
                return;
            }
        }
        cart.add(new CartItem(p, 1));
        if (cartButton != null) {
            cartButton.setText("Cart (" + cart.size() + ")");
        }
    }

    private void showCart() {
        CartView cartView = new CartView(cart, user);
        Stage stage = new Stage();
        stage.setTitle("Your Cart");
        stage.setScene(new javafx.scene.Scene(cartView.getView(), 600, 400));
        stage.show();
    }

    private void showOrderHistory() {
        OrderHistoryView orderHistoryView = new OrderHistoryView(user);
        javafx.scene.Scene scene = new javafx.scene.Scene(orderHistoryView.getView(), 900, 600);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        EcommerceApp.getPrimaryStage().setScene(scene);
    }
}
