package com.ecommerce.service;

import com.ecommerce.dao.OrderDAO;
import com.ecommerce.model.CartItem;
import com.ecommerce.model.User;

import java.util.List;

public class OrderService implements OrderCalculations {

    private OrderDAO orderDAO;

    public OrderService() {
        this.orderDAO = new OrderDAO();
    }

    @Override
    public double calculateTotal(List<CartItem> items) {
        double total = 0;
        for (CartItem item : items) {
            total += item.getTotalPrice();
        }
        return total;
    }

    @Override
    public double calculateTax(double amount) {
        return amount * 0.08; // 8% Tax
    }

    public void placeOrder(User user, List<CartItem> items) {
        double total = calculateTotal(items);
        double tax = calculateTax(total);
        double finalAmount = total + tax;

        orderDAO.placeOrder(user, items, finalAmount);
    }
}
